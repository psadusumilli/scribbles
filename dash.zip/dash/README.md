DASH

Instructions
- configure your src/main/resources/config.yml file
   - baseDir= folder to save the results 
   
- Dash starts in 9191 port
- configure "config.yaml" property in your application.properties file with the config.yml file (this file needs be in the resources folder)