package com.equifax.dep.dash.report;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Vijay Chakravarthy
 * @version %I% %G%
 * @since 1.0
 */
public class Run {
    private String name;
    private List<String> categories = new ArrayList<>();

    public Run(String name) {
        this.name = name;
    }

    public void addCategory(String category) {
        categories.add(category);
    }

    public String getName() {
        return name;
    }

    public List<String> getCategories() {
        return categories;
    }

    @Override
    public String toString() {
        return "Run{" +
                "name='" + name + '\'' +
                ", categories=" + categories +
                '}';
    }

    public void reset() {
        categories.clear();
    }
}
