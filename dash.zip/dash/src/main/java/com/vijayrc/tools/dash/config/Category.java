package com.equifax.dep.dash.config;

/**
 * @author Vijay Chakravarthy
 * @version %I% %G%
 * @since 1.0
 */
public class Category {
    public String name;
    public String fields;

    public Category(String name, String fields) {
        this.name = name;
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "Category [name=" + name + "|fields=" + fields + "]";
    }

}
