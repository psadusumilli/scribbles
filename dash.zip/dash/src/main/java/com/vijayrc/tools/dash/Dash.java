package com.equifax.dep.dash;

import com.equifax.dep.dash.parse.Parser;
import com.equifax.dep.dash.repo.AllRuns;
import com.equifax.dep.dash.report.Report;
import com.equifax.dep.dash.report.Run;
import com.equifax.dep.dash.source.Poller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.io.IOException;
import java.util.Collection;

/**
 * @author Vijay Chakravarthy
 * @version %I% %G%
 * @since 1.0
 */
@Service
public class Dash {

    @Autowired
    private Parser parser;

    @Autowired
    private Report report;

    @Autowired
    private Poller poller;

    @Autowired
    private AllRuns allRuns;

    private int runsCount;

    public void home(Model model) {
        Collection<Run> runs = allRuns.loadOldRuns();
        model.addAttribute("runs", runs);
        model.addAttribute("existCount", runs.size());
        model.addAttribute("runsCount", runsCount);
    }

    public void start(String build, Model model) throws Exception {
        poller.start(build);
        model.addAttribute("runsCount", ++runsCount);
    }

    public void stopAll(Model model) throws Exception {
        runsCount = 0;
        model.addAttribute("runsCount", runsCount);
        poller.stop();
        parser.start();
    }

    public void report(String runName, Model model) {
        report.publish(runName, model);
    }

    public String dataFor(String csvFile) throws IOException {
        return report.getCsvFor(csvFile);
    }

    public void redoReport(String runName, Model model) {
        parser.reparseRun(runName);
        report.publish(runName, model);
    }
}
