package com.equifax.dep.dash.repo;

import com.equifax.dep.dash.report.Run;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

import static org.apache.commons.io.FileUtils.listFiles;
import static org.apache.commons.lang.StringUtils.remove;
import static org.apache.commons.lang.StringUtils.removeEnd;

/**
 * @author Vijay Chakravarthy
 * @version %I% %G%
 * @since 1.0
 */
@Repository
public class AllRuns {

    private static Logger log = Logger.getLogger(AllRuns.class);

    @Autowired
    private AllConfigs allConfigs;

    private Map<String, Run> runs = new TreeMap<>();

    public Run getFor(String name) {
        if (!runs.containsKey(name)) runs.put(name, new Run(name));
        return runs.get(name);
    }

    /**
     * will recreate runs from json dump files and the csv files.
     */
    public Collection<Run> loadOldRuns() {
        try {
            File jsonDir = new File(allConfigs.getJsonDir());
            File csvDir = new File(allConfigs.getCsvDir());
            listFiles(jsonDir, new String[]{"txt"}, false).forEach(
                    jsonFile -> {
                        final String runName = removeEnd(jsonFile.getName(), ".txt").trim();
                        if (!runs.keySet().contains(runName)){
                            final Run run = new Run(runName);
                            listFiles(csvDir, getFileFilter(runName), null).forEach(csv -> run.addCategory(remove(remove(csv.getName(), runName + "-"), ".csv")));
                            runs.put(runName, run);
                            log.info("loaded " + run);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        log.info("existing runs: " + runs.size());
        return runs.values();
    }

    private IOFileFilter getFileFilter(final String runName) {
        return new IOFileFilter() {
            @Override
            public boolean accept(File file) {
                return file.getName().contains(runName);
            }

            @Override
            public boolean accept(File file, String s) {
                return file.getName().contains(runName);
            }
        };
    }

    public boolean isNewRun(String runName) {
        return !runs.keySet().contains(runName);
    }
}
