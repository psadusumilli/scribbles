package com.equifax.dep.dash.config;

import com.equifax.dep.dash.repo.AllConfigs;
import jdk.nashorn.internal.ir.annotations.Ignore;
import org.junit.Test;

/**
 * Created by vxr63 on 7/12/2015.
 */
public class ConfigTest {

    @Test
    @Ignore
    public void shouldReadYaml() throws Exception {
        AllConfigs allConfigs = new AllConfigs("C:/DEP/dash/src/main/resources/config-sio.yml");
        System.out.println(allConfigs);
    }

}